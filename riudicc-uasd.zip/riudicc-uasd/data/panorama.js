/* =====================================================================
   PANORAMA RIUDICC · DATOS REALES
   Fuente: Instituto de Estadística de la UNESCO (UIS), vía Our World in Data.
   out = estudiantes del país que estudian en otro país (% de la matrícula nacional)
   inn = estudiantes internacionales recibidos (% de la matrícula)
   ger = tasa bruta de matrícula en educación superior (%)
   oy, iy, gy = año de cada dato. Consulta: 2026-09-30.
   ===================================================================== */
window.PANORAMA = [
  { g: "lat", p: "República Dominicana", out: 1.04, oy: 2023, inn: 1.92, iy: 2024, ger: 57.7, gy: 2024, u: "UASD · Unicaribe" },
  { g: "lat", p: "México", out: 0.74, oy: 2023, inn: 2.04, iy: 2024, ger: 48.2, gy: 2024, u: "UNICACH · Universidad Politécnica de Chiapas" },
  { g: "lat", p: "Guatemala", out: 0.78, oy: 2023, inn: 0.43, iy: 2023, ger: 27.3, gy: 2023, u: "USAC · Universidad del Valle de Guatemala" },
  { g: "lat", p: "Ecuador", out: 3.35, oy: 2023, inn: 0.68, iy: 2023, ger: 67.9, gy: 2023, u: "Universidad del Azuay · Universidad Politécnica Salesiana" },
  { g: "eu", p: "España", out: 2.14, oy: 2023, inn: 4.65, iy: 2024, ger: 93.8, gy: 2024, u: "Universidad Complutense de Madrid (coordinadora)" },
  { g: "eu", p: "Italia", out: 3.92, oy: 2023, inn: 4.80, iy: 2023, ger: 75.9, gy: 2023, u: "Università degli Studi di Messina" }
];
window.PANORAMA_FUENTES = [
  { nombre: "Estudiantes que estudian en otro país (UNESCO UIS)", enlace: "https://ourworldindata.org/grapher/share-of-students-studying-abroad" },
  { nombre: "Estudiantes internacionales recibidos (UNESCO UIS)", enlace: "https://ourworldindata.org/grapher/share-of-students-from-abroad" },
  { nombre: "Tasa bruta de matrícula en educación superior (UNESCO UIS)", enlace: "https://ourworldindata.org/grapher/gross-enrollment-ratio-in-tertiary-education" }
];
