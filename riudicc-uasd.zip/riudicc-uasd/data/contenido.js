/* =====================================================================
   CONTENIDO DEL PORTAL RIUDICC–UASD
   Edite este archivo para actualizar textos, enlaces y listas.
   Cada bloque es una lista de elementos con el mismo formato.
   Fechas en formato AAAA-MM-DD.
   ===================================================================== */

window.SITIO = {
  correo: "srosario64@uasd.edu.do",
  actualizado: "2026-09-30",
  // Enlaces que se completan cuando existan:
  formularioMovilidad: "",   // enlace al formulario de Google Forms de autodeclaración
  tablonMovilidad: "https://claude.ai/artifact/JGUbhqcheKC7iVruvanK59"
};

/* ---------- Destacados de la portada ---------- */
window.DESTACADOS = [
  { etiqueta: "Convocatoria", fecha: "2026-10-06", titulo: "Becas Chevening 2027/2028: maestrías de un año en el Reino Unido",
    texto: "Cierra el 6 de octubre de 2026 a las 7:00 a. m. (hora de Santo Domingo). República Dominicana es país elegible.",
    enlace: "https://www.chevening.org/apply/", externo: true },
  { etiqueta: "Participa", titulo: "Registro de movilidad UASD 2023–2026",
    texto: "¿Viajaste a un congreso, hiciste una estancia o recibiste visitantes? Regístralo en dos minutos y ayuda a construir el primer mapa de movilidad de la UASD.",
    enlace: "#participa" },
  { etiqueta: "Datos", titulo: "Ecuador es el país de la red donde más estudiantes salen a estudiar fuera",
    texto: "3,35 % de su matrícula estudia en otro país, frente a 1,04 % en República Dominicana y 0,74 % en México (UNESCO, 2023).",
    enlace: "#panorama" },
  { etiqueta: "Red", titulo: "Tablón de movilidad RIUDICC",
    texto: "Intercambios, cursos cortos, estancias y becas que publican las universidades de la red, revisados por el micro-observatorio.",
    enlace: "#convocatorias" }
];

/* ---------- La red RIUDICC ---------- */
window.SOCIOS = [
  { pais: "España", universidades: ["Universidad Complutense de Madrid (coordinadora)"] },
  { pais: "Italia", universidades: ["Università degli Studi di Messina"] },
  { pais: "México", universidades: ["Universidad de Ciencias y Artes de Chiapas (UNICACH)", "Universidad Politécnica de Chiapas"] },
  { pais: "Guatemala", universidades: ["Universidad de San Carlos de Guatemala (USAC)", "Universidad del Valle de Guatemala (UVG)"] },
  { pais: "Ecuador", universidades: ["Universidad del Azuay (UDA)", "Universidad Politécnica Salesiana (UPS)"] },
  { pais: "República Dominicana", universidades: ["Universidad Autónoma de Santo Domingo (UASD)", "Universidad del Caribe (UNICARIBE)"] }
];

window.PAQUETES = [
  { wp: "WP1", tema: "Gestión y coordinación del proyecto", lideres: "Universidad Complutense de Madrid" },
  { wp: "WP2", tema: "Inclusión y movilidad de poblaciones vulnerables", lideres: "UASD · UNICACH", uasd: true },
  { wp: "WP3", tema: "Piloto de becas bilaterales y movilidad", lideres: "USAC · Universidad del Valle de Guatemala" },
  { wp: "WP4", tema: "Formación y fortalecimiento de capacidades", lideres: "Universidad del Caribe" },
  { wp: "WP5", tema: "Integración cultural y cooperación científica", lideres: "Università di Messina · Universidad Complutense de Madrid" },
  { wp: "WP6", tema: "Comunicación y difusión", lideres: "Universidad Politécnica Salesiana · Universidad Politécnica de Chiapas" },
  { wp: "WP7", tema: "Sostenibilidad: observatorio, micro-observatorios, clústeres e instituto", lideres: "Universidad del Azuay" }
];

/* ---------- La UASD y la internacionalización ---------- */
window.UASD = {
  texto: "La Universidad Autónoma de Santo Domingo, fundada el 28 de octubre de 1538, es la universidad pública de la República Dominicana. En RIUDICC co-lidera el paquete de trabajo sobre inclusión y movilidad de poblaciones vulnerables (WP2) y pone en marcha su micro-observatorio de movilidad.",
  oficinas: [
    { nombre: "Dirección General de Cooperación y Relaciones Nacionales e Internacionales", rol: "Convenios, movilidad y relaciones con universidades e instituciones del exterior." },
    { nombre: "Dirección de Becas", rol: "Tramita becas nacionales e internacionales para estudiantes, egresados, docentes e investigadores.", enlace: "https://uasd.edu.do/cooperacion-internacional/direccion-becas/" },
    { nombre: "Vicerrectoría de Investigación y Postgrado", rol: "Proyectos de investigación, postgrados, congresos y redes regionales como el SIRCIP del CSUCA." },
    { nombre: "Micro-observatorio de movilidad (RIUDICC)", rol: "Registro, análisis y difusión de la movilidad académica de la UASD.", enlace: "#observatorio" }
  ]
};

/* ---------- Movilidad e internacionalización: ideas y evidencia ---------- */
window.IDEAS = [
  { titulo: "Solo el 38 % de la movilidad que sale de América Latina y el Caribe se queda en la región",
    texto: "La mayoría de los estudiantes de la región que estudian fuera se van a Estados Unidos y Europa. Fortalecer la movilidad intrarregional es uno de los objetivos de redes como RIUDICC.",
    fuente: "UNESCO IESALC, 2019", enlace: "https://www.iesalc.unesco.org/2019/09/16/unesco-iesalc-desvela-que-solo-un-38-de-la-movilidad-que-sale-de-america-latina-y-el-caribe-se-queda-en-la-region/" },
  { titulo: "Los observatorios convierten datos dispersos en decisiones",
    texto: "En América Latina, los observatorios universitarios de internacionalización sirven para sistematizar información, comparar instituciones y orientar políticas. Su debilidad frecuente es la sostenibilidad cuando termina el financiamiento.",
    fuente: "Bahena Benítez y Morales Mejía, Revista GEON, 2019", enlace: "https://doi.org/10.22579/23463910.158" },
  { titulo: "La movilidad mejora competencias para el empleo",
    texto: "En una universidad estatal mexicana, estudiantes y egresados con movilidad internacional mostraron más competencias académicas que quienes no la hicieron, sobre todo en contextos internacionales y en responsabilidad social.",
    fuente: "González Jaimes y Salgado Vargas (372 estudiantes y egresados, 54 empleadores)" },
  { titulo: "Seis tipos de barreras limitan la movilidad inclusiva",
    texto: "El diagnóstico del WP2 de RIUDICC identificó barreras institucionales, económicas, regulatorias, sociales, tecnológicas y geográficas, y lingüísticas y culturales para estudiantes y personal en situación de vulnerabilidad.",
    fuente: "RIUDICC, WP2" },
  { titulo: "El MESCyT pide datos solo de la movilidad de investigadores",
    texto: "La Plantilla 13 del MESCyT registra la movilidad entrante y saliente de investigadores. La movilidad de estudiantes y personal no tiene un registro nacional: ese es el vacío que llena el micro-observatorio.",
    fuente: "MESCyT, Plantilla 13" }
];

/* ---------- Convocatorias y becas (se actualiza cada semana) ---------- */
window.CONVOCATORIAS = [
  { titulo: "Becas Chevening 2027/2028", entidad: "Gobierno del Reino Unido", pais: "Reino Unido", nivel: "Maestría", cierre: "2026-10-06", enlace: "https://www.chevening.org/apply/" },
  { titulo: "Becas Erasmus Mundus para maestrías conjuntas (ingreso 2027)", entidad: "Comisión Europea (EACEA)", pais: "Unión Europea", nivel: "Maestría", cierre: "", nota: "Cada maestría tiene su propio plazo, en general entre octubre y enero.", enlace: "https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en" }
];
window.ORGANISMOS_BECAS = [
  { pais: "República Dominicana", nombre: "MESCyT · becas internacionales", enlace: "https://mescyt.gob.do/noticias/mescyt-exhorta-a-jovenes-de-todo-el-territorio-nacional-postularse-a-becas-internacionales-2026/" },
  { pais: "República Dominicana", nombre: "UASD · Dirección de Becas", enlace: "https://uasd.edu.do/cooperacion-internacional/direccion-becas/" },
  { pais: "México", nombre: "SECIHTI · becas al extranjero", enlace: "https://secihti.mx/becas-al-extranjero/convocatorias-y-resultados-de-becas-al-extranjero/" },
  { pais: "Guatemala", nombre: "SEGEPLAN · portal de becas", enlace: "https://portal-becas.segeplan.gob.gt/becas_/busqueda" },
  { pais: "Ecuador", nombre: "SENESCYT · convocatorias", enlace: "https://siau.senescyt.gob.ec/portfolio/convocatorias/" },
  { pais: "España", nombre: "Fundación Carolina", enlace: "https://www.fundacioncarolina.es/convocatoria-de-becas-de-la-fundacion-carolina-20262027/" }
];

/* ---------- Biblioteca ---------- */
window.DOCUMENTOS = [
  { tipo: "politica", pais: "República Dominicana", titulo: "Informe general sobre estadísticas de educación superior 2024 y resumen histórico 2010–2024 (Parte 2)", autor: "MESCyT", anio: "2026", enlace: "https://mescyt.gob.do/wp-content/uploads/2026/03/INFORME-GENERAL-SOBRE-ESTADISTICAS-DE-EDUCACION-SUPERIOR-2024-PARTE-2.pdf", nota: "Matrícula extranjera por nacionalidad y docentes por país de origen." },
  { tipo: "politica", pais: "República Dominicana", titulo: "Tablero de estadísticas de educación superior", autor: "MESCyT", anio: "En línea", enlace: "https://mescyt.gob.do/tablero-de-estadisticas/", nota: "Matrícula, nuevos ingresos y becas nacionales e internacionales." },
  { tipo: "politica", pais: "Centroamérica y R. D.", titulo: "Quinto Plan para la Integración Regional de la Educación Superior de Centroamérica y República Dominicana (PIRESC V)", autor: "CSUCA", anio: "2021", enlace: "https://siesca.uned.ac.cr/images/PIRESC__V.pdf", nota: "Sistema de Internacionalización (SIESCA) y metas de movilidad." },
  { tipo: "politica", pais: "México", titulo: "Movilidad estudiantil en educación superior en México (2016-17, 2017-18 y 2018-19)", autor: "ANUIES", anio: "2022", enlace: "https://repositoriointernacional.anuies.mx/wp-content/uploads/2022/08/Reporte_movilidad_estudiantil-2017-2019.pdf", nota: "Serie nacional de movilidad por institución." },
  { tipo: "politica", pais: "Ecuador", titulo: "Reglamento de Régimen Académico", autor: "Consejo de Educación Superior (CES)", anio: "2022", enlace: "https://www.ces.gob.ec/wp-content/uploads/2022/08/Reglamento-de-Re%CC%81gimen-Acade%CC%81mico-vigente-a-partir-del-16-de-septiembre-de-2022.pdf", nota: "Reconocimiento, homologación y redes de movilidad." },
  { tipo: "politica", pais: "España", titulo: "Estrategia para la internacionalización de las universidades españolas 2015–2020 (resumen ejecutivo)", autor: "Ministerio de Educación, Cultura y Deporte", anio: "2015", enlace: "https://www.libreria.educacion.gob.es/ebook/180907/free_download/", nota: "Cuatro ejes y 28 medidas." },
  { tipo: "politica", pais: "Italia", titulo: "Rapporto Erasmus+ 2024", autor: "Agenzia Erasmus+ INDIRE", anio: "2025", enlace: "https://www.erasmusplus.it/news/istruzione-superiore/rapporto-erasmus-2024-cresce-la-partecipazione-italiana-negli-ambiti-scuola-universita-ed-educazione-degli-adulti/", nota: "36.082 movilidades en educación superior en 2024." },
  { tipo: "politica", pais: "América Latina y el Caribe", titulo: "Internacionalización y movilidad académica", autor: "UNESCO IESALC", anio: "En línea", enlace: "https://www.iesalc.unesco.org/category/prioridades/internacionalizacion-y-movilidad-academica/", nota: "Estudios regionales y convenio regional de reconocimiento." },
  { tipo: "riudicc", pais: "RIUDICC–UASD", titulo: "Ecosistema RIUDICC: observatorio, micro-observatorios, laboratorio e instituto interuniversitario", autor: "Suany Rosario (UASD)", anio: "2025", nota: "Documento de trabajo. Disponible a solicitud." },
  { tipo: "riudicc", pais: "RIUDICC–UASD", titulo: "Observatorio Interuniversitario RIUDICC de Movilidad Inclusiva y Cooperación Académica (RIUDICC-OBSERVA)", autor: "Suany Rosario (UASD)", anio: "2025", nota: "Propuesta. Disponible a solicitud." },
  { tipo: "riudicc", pais: "RIUDICC–UASD", titulo: "Encuesta de inclusión en la movilidad académica (WP2)", autor: "RIUDICC, WP2", anio: "2025", nota: "Instrumento aplicado a las universidades del consorcio." },
  { tipo: "riudicc", pais: "RIUDICC–UASD", titulo: "Propuesta de micro-observatorio de movilidad académica UASD", autor: "Micro-observatorio UASD", anio: "2026", nota: "Documento de trabajo. Disponible a solicitud." }
];

window.OBSERVATORIOS = [
  { sigla: "HEPO", nombre: "Observatorio de Políticas de Educación Superior", institucion: "UNESCO IESALC", texto: "Perfiles y comparación de políticas de educación superior de más de 140 países, con datos de la UNESCO.", enlace: "https://hepo.iesalc.unesco.org/pc/page/home/" },
  { sigla: "SITEAL", nombre: "Sistema de Información de Tendencias Educativas en América Latina", institucion: "IIPE UNESCO", texto: "Políticas, normativas y análisis comparados de los sistemas educativos de la región.", enlace: "https://siteal.iiep.unesco.org/" },
  { sigla: "OCUD", nombre: "Observatorio de la Cooperación Universitaria al Desarrollo", institucion: "Universidades españolas (CRUE)", texto: "Informes, guías de buenas prácticas y seguimiento de la cooperación universitaria en España.", enlace: "https://www.ocud.es/" },
  { sigla: "ORSALC", nombre: "Observatorio Regional de Responsabilidad Social para América Latina y el Caribe", institucion: "UNESCO IESALC", texto: "Red temática sobre responsabilidad social universitaria y territorial.", enlace: "https://orsalc.org/" },
  { sigla: "OBIRET", nombre: "Observatorio Regional sobre Internacionalización y Redes de Educación Terciaria", institucion: "Universidad de Guadalajara", texto: "Análisis sistemático de la internacionalización de la educación superior en la región." },
  { sigla: "OBSMAC", nombre: "Observatorio de Movilidades Académicas y Científicas", institucion: "DIE-CINVESTAV, México", texto: "Difusión en acceso libre de becas y programas de apoyo a la movilidad." },
  { sigla: "ODIE", nombre: "Observatorio de Diversidad Cultural e Interculturalidad en Educación Superior", institucion: "Colombia", texto: "Experiencias de educación superior intercultural en América Latina y el Caribe." }
];
