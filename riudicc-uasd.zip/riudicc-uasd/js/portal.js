/* Portal RIUDICC–UASD: dibuja las secciones a partir de data/contenido.js */
(function(){
  const $=id=>document.getElementById(id);
  const el=(t,c,x)=>{const e=document.createElement(t); if(c) e.className=c; if(x!=null) e.textContent=x; return e;};
  const MESES=["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
  const fecha=s=>{ if(!/^\d{4}-\d{2}-\d{2}$/.test(s||"")) return ""; const [y,m,d]=s.split("-").map(Number); return `${d} ${MESES[m-1]} ${y}`; };
  const link=(text,href,cls)=>{const a=el("a",cls||null,text); a.href=href; if(/^https?:/.test(href)){a.target="_blank"; a.rel="noopener noreferrer";} return a;};
  const S=window.SITIO||{};

  // Destacados
  const D=$("destacados");
  (window.DESTACADOS||[]).forEach(d=>{
    const a=link("",d.enlace,"dest"); a.textContent="";
    const top=el("div","dest-top"); top.append(el("span","tag",d.etiqueta)); if(d.fecha) top.append(el("span","dest-date","Cierra "+fecha(d.fecha)));
    a.append(top, el("h3",null,d.titulo), el("p",null,d.texto), el("span","more",/^https?:/.test(d.enlace)?"Abrir enlace ↗":"Ver más ↓"));
    D.append(a);
  });

  // Socios
  const So=$("socios");
  (window.SOCIOS||[]).forEach(s=>{const c=el("div","socio"); c.append(el("div","socio-pais",s.pais)); const ul=el("ul"); s.universidades.forEach(u=>ul.append(el("li",null,u))); c.append(ul); So.append(c);});
  const W=$("paquetes");
  (window.PAQUETES||[]).forEach(p=>{const r=el("div","wp"+(p.uasd?" uasd":"")); r.append(el("span","wp-n",p.wp), el("span","wp-t",p.tema), el("span","wp-l",p.lideres)); W.append(r);});

  // UASD
  if(window.UASD){ $("uasdTexto").textContent=UASD.texto; const O=$("oficinas");
    UASD.oficinas.forEach(o=>{const c=el("div","oficina"); const h=el("h3"); if(o.enlace) h.append(link(o.nombre,o.enlace)); else h.textContent=o.nombre; c.append(h, el("p",null,o.rol)); O.append(c);}); }

  // Ideas
  const I=$("ideas");
  (window.IDEAS||[]).forEach(i=>{const c=el("article","idea"); c.append(el("h3",null,i.titulo), el("p",null,i.texto)); const f=el("div","fuente"); if(i.enlace) f.append(link(i.fuente+" ↗",i.enlace)); else f.textContent=i.fuente; c.append(f); I.append(c);});

  // Convocatorias
  const C=$("convs");
  (window.CONVOCATORIAS||[]).forEach(c=>{const r=el("div","conv"); const d=el("div","conv-date"); d.textContent=c.cierre?fecha(c.cierre):"Plazos variables"; const b=el("div","conv-body"); b.append(link(c.titulo,c.enlace,"conv-t"), el("div","conv-m",[c.entidad,c.pais,c.nivel].filter(Boolean).join(" · "))); if(c.nota) b.append(el("div","conv-m",c.nota)); r.append(d,b); C.append(r);});
  const Og=$("organismos");
  (window.ORGANISMOS_BECAS||[]).forEach(o=>{const li=el("li"); li.append(el("span","org-p",o.pais+": "), link(o.nombre,o.enlace)); Og.append(li);});
  const T=$("tablonLink"); if(T && S.tablonMovilidad){ T.href=S.tablonMovilidad; }

  // Biblioteca con filtro
  const B=$("docs"), chips=document.querySelectorAll(".chip");
  function docs(tipo){ B.textContent=""; (window.DOCUMENTOS||[]).filter(d=>!tipo||d.tipo===tipo).forEach(d=>{const c=el("article","doc"); c.append(el("div","c",d.pais)); if(d.enlace) c.append(link(d.titulo,d.enlace)); else c.append(el("strong",null,d.titulo)); c.append(el("div","m",`${d.autor} · ${d.anio}`)); if(d.nota) c.append(el("div","m",d.nota)); B.append(c);}); }
  chips.forEach(ch=>ch.addEventListener("click",()=>{chips.forEach(x=>x.setAttribute("aria-pressed",String(x===ch))); docs(ch.dataset.tipo);}));
  docs("");
  const Ob=$("observatorios");
  (window.OBSERVATORIOS||[]).forEach(o=>{const c=el("article","obs"); const h=el("h3"); h.append(el("span","sigla",o.sigla+" ")); h.append(o.nombre); c.append(h, el("div","m",o.institucion), el("p",null,o.texto)); if(o.enlace) c.append(link("Visitar ↗",o.enlace,"more")); Ob.append(c);});

  // Participa
  const Fm=$("formLink");
  if(Fm){ if(S.formularioMovilidad){ Fm.href=S.formularioMovilidad; Fm.target="_blank"; Fm.rel="noopener noreferrer"; } else { Fm.removeAttribute("href"); Fm.classList.add("disabled"); Fm.textContent="Formulario disponible pronto"; } }
  document.querySelectorAll("[data-correo]").forEach(n=>{ n.textContent=S.correo||""; });
  const U=$("actualizado"); if(U) U.textContent=fecha(S.actualizado);

  // Navegación activa
  const links=[...document.querySelectorAll(".nav a")];
  const secs=links.map(a=>document.querySelector(a.getAttribute("href"))).filter(Boolean);
  if("IntersectionObserver" in window){
    const io=new IntersectionObserver(es=>{es.forEach(e=>{ if(e.isIntersecting){ links.forEach(a=>a.classList.toggle("on",a.getAttribute("href")==="#"+e.target.id)); } });},{rootMargin:"-40% 0px -55% 0px"});
    secs.forEach(s=>io.observe(s));
  }
})();
