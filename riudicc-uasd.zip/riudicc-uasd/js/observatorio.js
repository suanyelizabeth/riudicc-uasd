/* Observatorio de movilidad: panorama real + demostración con datos ficticios */
(function(){

const DATA=window.DEMO;
const SD=[-69.93,18.47];
const $=id=>document.getElementById(id);
const el=(t,c,x)=>{const e=document.createElement(t); if(c) e.className=c; if(x!=null) e.textContent=x; return e;};
const css=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const F={sentido:"",dimension:"",perfil:"",facultad:"",anio:""};
const uniq=k=>[...new Set(DATA.rows.map(r=>r[k]))].sort();
uniq("perfil").forEach(v=>$("fPerfil").add(new Option(v,v)));
uniq("facultad").forEach(v=>$("fFac").add(new Option(v,v)));
uniq("anio").forEach(v=>$("fAnio").add(new Option(String(v),String(v))));
document.querySelectorAll(".seg button").forEach(b=>b.addEventListener("click",()=>{
  F[b.dataset.f]=b.dataset.v; b.parentElement.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",String(x===b))); update();}));
$("fPerfil").addEventListener("input",e=>{F.perfil=e.target.value;update();});
$("fFac").addEventListener("input",e=>{F.facultad=e.target.value;update();});
$("fAnio").addEventListener("input",e=>{F.anio=e.target.value;update();});
$("reset").addEventListener("click",()=>{Object.keys(F).forEach(k=>F[k]=""); ["fPerfil","fFac","fAnio"].forEach(i=>$(i).value="");
  document.querySelectorAll(".seg").forEach(s=>s.querySelectorAll("button").forEach((x,i)=>x.setAttribute("aria-pressed",String(i===0)))); update();});

function filtered(){return DATA.rows.filter(r=>(!F.sentido||r.sentido===F.sentido)&&(!F.dimension||r.dimension===F.dimension)&&(!F.perfil||r.perfil===F.perfil)&&(!F.facultad||r.facultad===F.facultad)&&(!F.anio||String(r.anio)===F.anio));}
function count(rows,key){const m=new Map(); rows.forEach(r=>{const k=r[key]; const o=m.get(k)||{k,out:0,in:0}; if(r.sentido==="SALIENTE") o.out++; else o.in++; m.set(k,o);}); return [...m.values()].map(o=>({...o,t:o.out+o.in})).sort((a,b)=>b.t-a.t);}
const pct=(a,b)=>b?Math.round(a*100/b)+"%":"–";
const tip=$("tip");
function hover(node,text){node.addEventListener("pointermove",e=>{tip.textContent=text; tip.hidden=false; tip.style.left=Math.min(e.clientX+12,innerWidth-270)+"px"; tip.style.top=(e.clientY+14)+"px";}); node.addEventListener("pointerleave",()=>tip.hidden=true);}

function kpis(rows){
  const K=$("kpis"); K.textContent="";
  const out=rows.filter(r=>r.sentido==="SALIENTE").length, inn=rows.length-out;
  const intl=rows.filter(r=>r.dimension==="INTERNACIONAL");
  const paises=new Set(intl.map(r=>r.pais)).size;
  const muj=rows.filter(r=>r.sexo==="FEMENINO").length;
  const disc=rows.filter(r=>r.discapacidad).length;
  const tiles=[
    [String(rows.length),"movilidades registradas",null],
    [null,"salientes · entrantes",[out,inn]],
    [pct(intl.length,rows.length),"internacionales",`${paises} países`],
    [pct(muj,rows.length),"mujeres",`${muj} de ${rows.length}`],
    [String(disc),"con discapacidad declarada","preguntas A–F del MESCyT"]];
  tiles.forEach(([v,l,s])=>{const d=el("div","kpi");
    if(Array.isArray(s)){const vv=el("div","v"); const a=el("span"); a.append(el("span","dot out")," "+s[0]); const b=el("span"); b.append(el("span","dot in")," "+s[1]); vv.append(a,"  ",b); d.append(vv,el("div","l",l));}
    else{d.append(el("div","v",v),el("div","l",l)); if(s) d.append(el("div","s",s));}
    K.append(d);});
}

function hbars(id,rows,key,max,split){
  const B=$(id); B.textContent=""; let data=count(rows,key); if(max&&data.length>max){const rest=data.slice(max); data=data.slice(0,max); const o={k:"Otros ("+rest.length+")",out:0,in:0}; rest.forEach(r=>{o.out+=r.out;o.in+=r.in;}); o.t=o.out+o.in; data.push(o);}
  const top=Math.max(1,...data.map(d=>d.t));
  if(!data.length){B.append(el("p","sub","Sin registros con estos filtros.")); return;}
  data.forEach(d=>{const row=el("div","hb"); row.append(el("span","name",d.k.trim()));
    const tr=el("div","track");
    if(split){ if(d.out){const a=el("span","seg1"+(d.in?" join":"")); a.style.width=(d.out/top*100)+"%"; tr.append(a);} if(d.in){const b=el("span","seg2"); b.style.width=(d.in/top*100)+"%"; tr.append(b);} }
    else {const a=el("span","seg1"); a.style.width=(d.t/top*100)+"%"; a.style.background="var(--accent)"; tr.append(a);}
    row.append(tr, el("span","val",String(d.t)));
    hover(row, `${d.k.trim()}: ${d.t} (salientes ${d.out}, entrantes ${d.in})`);
    B.append(row);});
}

function cols(rows){
  const C=$("cols"), X=$("colx"); C.textContent=""; X.textContent="";
  const per=[...new Set(DATA.rows.map(r=>r.periodo))].sort((a,b)=>a.localeCompare(b,"es",{numeric:true}));
  const data=per.map(p=>{const rs=rows.filter(r=>r.periodo===p); const out=rs.filter(r=>r.sentido==="SALIENTE").length; return {p,out,in:rs.length-out};});
  const top=Math.max(1,...data.map(d=>Math.max(d.out,d.in)));
  data.forEach(d=>{const c=el("div","col"+(d.p==="2026-II"?" partial":"")); const pr=el("div","pair");
    const a=el("div","b out"); a.style.height=(d.out/top*100)+"%"; const b=el("div","b in"); b.style.height=(d.in/top*100)+"%";
    pr.append(a,b); c.append(pr); const t=el("div","tot",String(d.out+d.in)); t.style.bottom=(Math.max(d.out,d.in)/top*100)+"%"; t.style.transform="translateY(-4px)"; c.append(t);
    hover(c,`${d.p}: ${d.out} salientes, ${d.in} entrantes${d.p==="2026-II"?" (semestre en curso)":""}`);
    C.append(c); X.append(el("span",null,d.p));});
}

function table(rows){
  const T=$("tbody"); T.textContent=""; const sorted=[...rows].sort((a,b)=>b.fecha.localeCompare(a.fecha));
  const lim=table.lim||25; sorted.slice(0,lim).forEach(r=>{const tr=el("tr");
    const f=r.fecha.split("-"); tr.append(el("td","mono",`${f[2]}/${f[1]}/${f[0]}`));
    const s=el("td"); s.append(el("span","pill "+(r.sentido==="SALIENTE"?"out":"in"),r.sentido==="SALIENTE"?"Saliente":"Entrante")); tr.append(s);
    [r.perfil,r.facultad,r.pais,r.institucion,r.razon.trim(),r.organismo].forEach(v=>tr.append(el("td",null,v))); T.append(tr);});
  $("tblCount").textContent=`${Math.min(lim,rows.length)} de ${rows.length}, más recientes primero`;
  $("more").hidden=rows.length<=lim;
}
$("more").addEventListener("click",()=>{table.lim=(table.lim||25)+50; table(filtered());});

// ---------- Mapa ----------
let chart=null, mapOK=false;
function mapList(rows){
  const L=$("maplist"); L.textContent="";
  const intl=rows.filter(r=>r.dimension==="INTERNACIONAL"); const data=count(intl,"pais");
  L.append(el("div","sub",intl.length?`${intl.length} internacionales en ${data.length} países`:"Sin movilidades internacionales con estos filtros"));
  data.slice(0,10).forEach(d=>{const r=el("div","row"); const n=el("span"); n.append(d.k); r.append(n, el("span","n",`${d.out} · ${d.in}`)); L.append(r);});
  if(data.length) L.append(el("div","sub","Cifras: salientes · entrantes"));
  const nac=rows.filter(r=>r.dimension==="NACIONAL");
  $("mapNote").textContent = nac.length ? `Además, ${nac.length} movilidades nacionales con ${new Set(nac.map(r=>r.institucion)).size} instituciones dominicanas (${count(nac,"institucion").slice(0,3).map(d=>d.k).join(", ")}…).` : "";
}
function drawMap(rows){
  if(!mapOK) return;
  const intl=rows.filter(r=>r.dimension==="INTERNACIONAL"); const data=count(intl,"pais");
  const top=Math.max(1,...data.map(d=>d.t));
  const cOut=css("--s-out"), cIn=css("--s-in"), ink=css("--ink"), muted=css("--muted"), surf=css("--surface");
  const reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
  const lines=(dir)=>data.filter(d=>dir==="out"?d.out:d.in).map(d=>{const c=DATA.coords[d.k]; const n=dir==="out"?d.out:d.in;
    return {name:d.k, value:n, coords: dir==="out"?[SD,c]:[c,SD], lineStyle:{width:1+3*n/top}};});
  chart.setOption({
    backgroundColor:"transparent",
    tooltip:{trigger:"item",backgroundColor:ink,borderWidth:0,textStyle:{color:surf,fontSize:12},
      formatter:p=>{ if(p.seriesType==="lines") return `${p.seriesName}: ${p.data.name} · ${p.data.value}`; if(p.seriesType==="scatter"){const d=p.data.raw; return d?`${d.k}<br/>Salientes ${d.out} · Entrantes ${d.in}`:"Santo Domingo · UASD";} return ""; }},
    geo:{map:"world",roam:false,silent:true,boundingCoords:[[-128,58],[146,-44]],itemStyle:{areaColor:css("--land"),borderColor:css("--land-edge"),borderWidth:.6},emphasis:{disabled:true}},
    series:[
      {name:"Salientes",type:"lines",coordinateSystem:"geo",zlevel:1,data:lines("out"),lineStyle:{color:cOut,opacity:.75,curveness:.22},effect:{show:!reduce,period:6,trailLength:0,symbol:"circle",symbolSize:4,color:cOut}},
      {name:"Entrantes",type:"lines",coordinateSystem:"geo",zlevel:1,data:lines("in"),lineStyle:{color:cIn,opacity:.75,curveness:-.22},effect:{show:!reduce,period:6,trailLength:0,symbol:"circle",symbolSize:4,color:cIn}},
      {type:"scatter",coordinateSystem:"geo",zlevel:2,data:data.map(d=>({value:DATA.coords[d.k].concat(d.t),raw:d,label:{show:d.t>=top*.45}})),
        symbolSize:v=>6+14*Math.sqrt(v[2]/top),itemStyle:{color:surf,borderColor:ink,borderWidth:1.5},
        label:{position:"right",formatter:p=>p.data.raw.k,color:ink,fontSize:11,fontFamily:"Source Sans 3"}},
      {type:"scatter",coordinateSystem:"geo",zlevel:3,data:[{value:SD.concat(0)}],symbolSize:12,itemStyle:{color:css("--accent"),borderColor:surf,borderWidth:2},
        label:{show:true,position:"bottom",formatter:"UASD",color:ink,fontWeight:600,fontSize:11}}
    ]},true);
}
function initMap(){
  if(!window.echarts || !echarts.getMap || !echarts.getMap("world")){ const M=$("map"); M.style.aspectRatio="auto"; M.style.minHeight="0"; M.append(el("p","sub","El mapa no pudo cargarse en esta vista. La lista de países de la derecha muestra los mismos datos.")); return; }
  mapOK=true; chart=echarts.init($("map"),null,{renderer:"svg"});
  new ResizeObserver(()=>chart&&chart.resize()).observe($("map"));
  const rerender=()=>drawMap(filtered());
  matchMedia("(prefers-color-scheme: dark)").addEventListener("change",rerender);
  new MutationObserver(rerender).observe(document.documentElement,{attributes:true,attributeFilter:["data-theme"]});
}

// ---------- Exportación Plantilla 13 ----------
const H_OUT=["RECINTO, CENTRO O SUBCENTRO DE LA IES AL QUE CORRESPONDEN LOS DATOS","TIPO DE DE DOCUMENTO DE IDENTIDAD","DOCUMENTO DE IDENTIDAD DEL INVESTIGADOR: CÉDULA O PASAPORTE(ID)","NOMBRES DEL INVESTIGADOR","PRIMER APELLIDO ","SEGUNDO APELLIDO ","SEXO","FECHA DE NACIMIENTO (dd/mm/aaaa)","PAIS DE ORIGEN (NACIMIENTO)","PAIS DE DESTINO ( a qué país va el investigador de RD) cuando la movilidad es internacional)","INSTITUCIÓN DE INTERCAMBIO (A DONDE VA EL INVESTIGADOR)","DURACIÓN DEL INTERCAMBIO","ÁREA PRINCIPAL DE INVESTIGACIÓN","NIVEL ACADÉMICO MAS ALTO ALCANZADO POR EL INVESTIGADOR","RAZON DE LA MOVILIDAD","MODALIDAD","DIMENSION DE LA MOVILIDAD","ACUERDO O CONVENIDO DE MOVILIDAD","EDAD CUMPLIDA","A. DIFICULTAD PARA VER INCLUSO SI USA LENTES","B. DIFICULTAD PARA OÍR AUN CUANDO USA UN APARATO AUDITIVO","C. DIFICULTAD PARA CAMINAR O SUBIR ESCALONES","D. DIFICULTAD PARA RECORDAR O CONCENTRARSE","E. DIFICULTAD PARA REALIZAR TAREAS (NECESITA SOPORTE PARA REALIZAR SU TRABAJO)","F. DIFICULTAD PARA COMUNICARSE (PARA ENTENDER A LAS Y LOS DEMÁS Y PARA QUE LA O LO ENTIENDAN)"];
const H_IN=H_OUT.slice(0,9).concat(["PAIS DE PROCEDENCIA ( de qué país viene a la R.D., cuando la movilidad es internacional)","INSTITUCIÓN DE INTERCAMBIO (DE DONDE VIENE EL INVESTIGADOR)","DURACIÓN DEL INTERCAMBIO","ÁREA PRINCIPAL DE INVESTIGACIÓN","HORAS DEDICADAS A LA INVESTIGACIÓN (SEMANALMENTE) ","TIEMPO DE DEDICACIÓN"]).concat(H_OUT.slice(13));
const NO="1. No, ninguna dificultad.", SI="2. Sí, cierta dificultad.";
const mescytRows=(rows,s)=>rows.filter(r=>r.sentido===s&&(r.perfil==="Docente"||r.perfil==="Investigador"));
function csvCell(v){v=v==null?"":String(v); return /[",\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}
function toCSV(rows,s){
  const H=s==="SALIENTE"?H_OUT:H_IN; const lines=[H.map(csvCell).join(",")];
  rows.forEach((r,i)=>{const n=Number(r.id.slice(1)); const y=r.anio-r.edad; const disc=[NO,NO,NO,NO,NO,NO]; if(r.discapacidad) disc[n%6]=SI;
    const base=[r.recinto,"CÉDULA",`000-${String(n).padStart(7,"0")}-0`,"EJEMPLO",`Registro ${r.id}`,"Ficticio",r.sexo,`15/06/${y}`,r.origen_nac,
      r.dimension==="NACIONAL"?"República Dominicana":r.pais, r.institucion, r.duracion, r.area];
    const mid= s==="SALIENTE" ? [] : ["6 horas","Semanal"];
    const tail=[r.nivel, r.razon, r.modalidad, r.dimension, r.organismo, r.edad].concat(disc);
    lines.push(base.concat(mid,tail).map(csvCell).join(","));});
  return "﻿"+lines.join("\r\n");
}
const toast=m=>{const t=$("toast"); t.textContent=m; t.hidden=false; clearTimeout(toast.t); toast.t=setTimeout(()=>t.hidden=true,3500);};
let DL=null;
async function download(s){
  const rows=mescytRows(filtered(),s); if(!rows.length){toast("No hay docentes ni investigadores con estos filtros."); return;}
  const name=`Plantilla13_movilidad_${s==="SALIENTE"?"salientes":"entrantes"}_DEMO.csv`, data=toCSV(rows,s);
  if(DL){ try{ await DL.save({filename:name, data}); }catch(e){ if(e&&e.code!=="declined") toast("No se pudo preparar el archivo."); } return; }
  const url=URL.createObjectURL(new Blob([data],{type:"text/csv;charset=utf-8"})); const a=document.createElement("a"); a.href=url; a.download=name; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),2000);
}
$("dlOut").addEventListener("click",()=>download("SALIENTE"));
$("dlIn").addEventListener("click",()=>download("ENTRANTE"));


const fmt=n=>n.toFixed(2).replace(".",",")+" %";
function panorama(){
  const P=window.PANORAMA||[]; const C=$("cmp"); if(!C) return; const top=Math.max(...P.map(p=>Math.max(p.out,p.inn)));
  [["lat","Núcleo latinoamericano"],["eu","Socios europeos (destino)"]].forEach(([g,label])=>{
    C.append(el("div","grp",label));
    P.filter(p=>p.g===g).forEach(p=>{
      const row=el("div","c"); row.append(el("span","cn",p.p));
      const bars=el("div","bars");
      [["out",p.out,p.oy],["in",p.inn,p.iy]].forEach(([k,v,y])=>{const br=el("div","br"); const tr=el("div"); const b=el("div","t "+k); b.style.width=(v/top*100)+"%"; tr.append(b); br.append(tr, el("span","v",fmt(v))); bars.append(br); hover(br,`${p.p}: ${k==="out"?"estudian en otro país":"estudiantes internacionales recibidos"} ${fmt(v)} (${y})`);});
      row.append(bars); C.append(row);});
  });
  C.append(el("div","axisnote","Escala común de 0 a "+fmt(top)));
  const Fi=$("fichas");
  P.forEach(p=>{const c=el("article","ficha"+(p.g==="eu"?" eu":""));
    c.append(el("h3",null,p.p), el("div","uni","RIUDICC: "+p.u));
    const dl=el("dl");
    [["Estudian en otro país",fmt(p.out),p.oy],["Internacionales recibidos",fmt(p.inn),p.iy],["Cobertura en ed. superior",p.ger.toFixed(1).replace(".",",")+" %",p.gy]].forEach(([a,b,y])=>{const dd=el("dd",null,b); dd.append(el("small",null,String(y))); dl.append(el("dt",null,a),dd);});
    c.append(dl); Fi.append(c);});
  const S=$("panoSrc"); if(S) (window.PANORAMA_FUENTES||[]).forEach((f,i)=>{ if(i) S.append(" · "); const a=el("a",null,f.nombre); a.href=f.enlace; a.target="_blank"; a.rel="noopener noreferrer"; S.append(a);});
}
panorama();

function update(){
  const rows=filtered(); kpis(rows); mapList(rows); drawMap(rows); cols(rows);
  hbars("bRazon",rows,"razon",7,false); hbars("bOrg",rows,"organismo",8,false); hbars("bFac",rows,"facultad",9,true); hbars("bPerfil",rows,"perfil",6,true);
  const nac=rows.filter(r=>r.dimension==="NACIONAL").length; $("nacNote").textContent=`${pct(nac,rows.length)} de las movilidades son nacionales (con otras instituciones dominicanas).`;
  const o=mescytRows(rows,"SALIENTE").length, i=mescytRows(rows,"ENTRANTE").length;
  $("mescytCount").textContent=`Con los filtros actuales: ${o} salientes y ${i} entrantes de docentes e investigadores. Los nombres y cédulas del archivo de demostración son marcadores.`;
  table.lim=25; table(rows);
}
update();
window.addEventListener("load",()=>{ initMap(); drawMap(filtered()); });
(async()=>{ try{ DL=window.claude&&window.claude.use ? await window.claude.use("downloads") : null; }catch(e){ DL=null; } })();

})();
