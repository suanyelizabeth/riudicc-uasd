# Portal RIUDICC–UASD

Portal del micro-observatorio de movilidad académica de la Universidad Autónoma de Santo Domingo (UASD) en la red RIUDICC (Erasmus+ 2024–2027).

El sitio reúne en una sola página:

- **Inicio:** cifras de la red y destacados.
- **La red:** universidades socias y paquetes de trabajo.
- **UASD internacional:** oficinas que trabajan con la movilidad.
- **Movilidad:** hallazgos de la evidencia.
- **Convocatorias:** becas abiertas y organismos de becas por país.
- **Biblioteca:** documentos por país y observatorios de referencia.
- **Participa:** formulario de registro, tablón de ofertas y contacto.
- **Observatorio:**
  - el panorama real de los países de la red (datos de la UNESCO);
  - el tablero del micro-observatorio UASD (por ahora con **datos ficticios** de demostración).

Es un sitio estático: HTML, CSS y JavaScript, sin servidor ni base de datos. Funciona en GitHub Pages sin costo.

## Estructura

```
index.html                 Página del portal
css/estilos.css            Estilos (modo claro y oscuro)
js/portal.js               Dibuja las secciones del portal
js/observatorio.js         Panorama y tablero del observatorio
data/contenido.js          ← TEXTOS, ENLACES Y LISTAS (lo que más se edita)
data/panorama.js           Datos reales de la UNESCO por país
data/movilidades-demo.js   Datos FICTICIOS del tablero (se reemplazan por los reales)
.nojekyll                  Indica a GitHub Pages que publique los archivos tal cual
```

## Cómo actualizar el contenido

Casi todo se cambia en `data/contenido.js`, sin tocar el HTML:

| Para cambiar… | Edite en `data/contenido.js` |
| --- | --- |
| Correo de contacto, fecha de actualización, enlace del formulario | `window.SITIO` |
| Tarjetas destacadas de la portada | `window.DESTACADOS` |
| Universidades y paquetes de trabajo | `window.SOCIOS`, `window.PAQUETES` |
| Texto y oficinas de la UASD | `window.UASD` |
| Hallazgos de la sección Movilidad | `window.IDEAS` |
| Becas abiertas y organismos por país | `window.CONVOCATORIAS`, `window.ORGANISMOS_BECAS` |
| Biblioteca | `window.DOCUMENTOS` (`tipo: "politica"` o `tipo: "riudicc"`) |
| Observatorios de referencia | `window.OBSERVATORIOS` |

Copie un elemento existente, péguelo debajo y cambie sus valores. Las fechas van en formato `AAAA-MM-DD`. Cuando exista el formulario de Google Forms, pegue su enlace en `formularioMovilidad` y el botón "Registra tu movilidad" se activará solo.

## Cómo publicarlo en GitHub Pages

1. Cree una cuenta en [github.com](https://github.com) (o use la que ya tenga).
2. Cree un repositorio nuevo, público, llamado `riudicc-uasd`.
3. En el repositorio, pulse **Add file → Upload files** y arrastre **todo el contenido** de esta carpeta (incluidas las carpetas `css`, `js` y `data`). Pulse **Commit changes**.
4. Vaya a **Settings → Pages**. En **Source** elija **Deploy from a branch**, rama `main`, carpeta `/ (root)`, y pulse **Save**.
5. En uno o dos minutos el sitio queda en `https://SU-USUARIO.github.io/riudicc-uasd/`.

Para editar después, abra el archivo en GitHub, pulse el lápiz (**Edit**), haga el cambio y pulse **Commit changes**. El sitio se actualiza solo.

## Datos del observatorio

- **Panorama RIUDICC (real):** tasas de movilidad saliente y entrante, y tasa bruta de matrícula en educación superior, del Instituto de Estadística de la UNESCO (UIS), consultadas vía Our World in Data el 30 de septiembre de 2026. Se actualizan en `data/panorama.js`.
- **Tablero del micro-observatorio (ficticio):** 244 registros inventados con el vocabulario de la Plantilla 13 del MESCyT. Cuando exista el registro real, exporte la hoja de Google Sheets a JSON con las mismas columnas y reemplace `data/movilidades-demo.js`. El botón "Reporte al MESCyT" exporta las movilidades de docentes e investigadores con las columnas de la Plantilla 13.
- **Mapa:** usa ECharts 4.9.0 y su mapa mundial, cargados desde CDN públicos.

## Avisos

- Sitio en desarrollo. No es todavía un sitio oficial de la UASD; no use logotipos institucionales sin autorización.
- Proyecto cofinanciado por el programa Erasmus+ de la Unión Europea (RIUDICC, 101178033). El pie de página incluye el aviso de responsabilidad de la Unión Europea.
- No publique datos personales: el tablero y los informes muestran solo cifras agregadas (Ley 172-13).
